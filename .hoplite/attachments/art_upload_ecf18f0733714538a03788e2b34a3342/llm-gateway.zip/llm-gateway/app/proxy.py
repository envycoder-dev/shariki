"""Public client API: OpenAI- and Anthropic-compatible endpoints with routing, fallback and billing."""
import collections
import datetime as dt
import json
import secrets
import time

import httpx
from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse, StreamingResponse
from sqlalchemy import select, update

from . import errors, settings_store
from .adapters import (AnthropicStreamToOpenAI, anthropic_to_openai, anthropic_usage, estimate_tokens,
                       openai_to_anthropic)
from .billing import calc, record, record_bg, sale_prices, usd
from .db import SessionLocal
from .models import NANO, ApiKey, Model, Provider, ProviderKey, User, now
from .security import decrypt, hash_key

router = APIRouter(prefix="/v1")
http = httpx.AsyncClient(timeout=httpx.Timeout(300, connect=15),
                         limits=httpx.Limits(max_connections=2000, max_keepalive_connections=200))

_rr = collections.defaultdict(int)
_rate: dict[int, collections.deque] = collections.defaultdict(collections.deque)
MAX_ATTEMPTS = 6
BAD_JSON = ("Тело запроса не является корректным JSON. Проверьте кавычки и запятые и передайте заголовок "
            "«Content-Type: application/json».")


async def read_body(request: Request) -> dict:
    try:
        body = await request.json()
    except (json.JSONDecodeError, UnicodeDecodeError):
        raise GatewayError(400, BAD_JSON, code="invalid_json")
    if not isinstance(body, dict):
        raise GatewayError(400, "Тело запроса должно быть JSON-объектом: {\"model\": ..., ...}", code="invalid_json")
    return body


def check_messages(body: dict):
    msgs = body.get("messages")
    if not isinstance(msgs, list) or not msgs:
        raise GatewayError(400, "Поле \"messages\" обязательно и должно быть непустым списком, например "
                                "[{\"role\": \"user\", \"content\": \"Привет\"}].", code="messages_required")


class GatewayError(Exception):
    def __init__(self, status, message, type_="invalid_request_error", code=None, headers=None):
        self.status, self.message, self.type, self.code = status, message, type_, code
        self.headers = headers or {}


def error_response(e: GatewayError, rid: str = "", anthropic=False):
    if anthropic:
        body = {"type": "error", "error": {"type": e.type, "message": e.message}}
    else:
        body = {"error": {"message": e.message, "type": e.type, "code": e.code}}
    h = dict(e.headers)
    if rid:
        h["X-Request-ID"] = rid
    return JSONResponse(body, status_code=e.status, headers=h or None)


def client_ip(request: Request) -> str:
    fwd = request.headers.get("x-forwarded-for")
    return fwd.split(",")[0].strip() if fwd else (request.client.host if request.client else "")


class Ctx:
    """Everything resolved before calling upstream."""

    def __init__(self, user, key, model, markup, rid, ip, endpoint):
        self.user, self.key, self.model, self.rid, self.ip, self.endpoint = user, key, model, rid, ip, endpoint
        self.price_in, self.price_out = sale_prices(model, markup)
        self.t0 = time.perf_counter()

    def bill_kwargs(self, provider_id, provider_key_id, tin, tout, stream, status=200, error="", attempts=1):
        return dict(request_id=self.rid, user_id=self.user.id, api_key_id=self.key.id,
                    model_name=self.model.public_id, provider_id=provider_id, provider_key_id=provider_key_id,
                    endpoint=self.endpoint, stream=stream, tokens_in=tin, tokens_out=tout,
                    cost=calc(tin, tout, self.model.cost_in, self.model.cost_out) if status < 400 else 0,
                    price=calc(tin, tout, self.price_in, self.price_out) if status < 400 else 0,
                    latency_ms=int((time.perf_counter() - self.t0) * 1000), status_code=status, error=error,
                    ip=self.ip, attempts=attempts)

    def headers(self, tin=0, tout=0):
        h = {"X-Request-ID": self.rid}
        if tin or tout:
            h["X-Cost"] = f"{usd(calc(tin, tout, self.price_in, self.price_out)):.9f}"
        return h


async def resolve(request: Request, body: dict, endpoint: str, kinds=("chat",)) -> Ctx:
    auth = request.headers.get("authorization", "")
    raw = auth[7:].strip() if auth.lower().startswith("bearer ") else request.headers.get("x-api-key", "").strip()
    if not raw:
        raise GatewayError(401, "Не передан API-ключ. Добавьте заголовок «Authorization: Bearer sk-gw-…». "
                                f"Создать ключ: {errors.KEYS_URL}", "authentication_error", "missing_api_key")
    async with SessionLocal() as s:
        key = (await s.execute(select(ApiKey).where(ApiKey.key_hash == hash_key(raw)))).scalar_one_or_none()
        if not key or not key.is_active:
            if key and not key.is_active:
                raise GatewayError(401, f"API-ключ «{key.name}» отключён. Включите его или создайте новый: "
                                        f"{errors.KEYS_URL}", "authentication_error", "invalid_api_key")
            raise GatewayError(401, "API-ключ не найден. Проверьте, что он скопирован полностью, или создайте "
                                    f"новый: {errors.KEYS_URL}", "authentication_error", "invalid_api_key")
        user = await s.get(User, key.user_id)
        if not user or user.is_blocked:
            raise GatewayError(403, "Аккаунт заблокирован. Обратитесь в поддержку.", "permission_error",
                               "account_blocked")
        if user.balance <= 0:
            raise GatewayError(402, f"Недостаточно средств: на балансе ${usd(user.balance):.2f}. "
                                    f"Пополните баланс: {errors.BILLING_URL}", "insufficient_quota",
                               "insufficient_balance")
        if key.spend_limit is not None and key.spent >= key.spend_limit:
            raise GatewayError(402, f"Ключ «{key.name}» израсходовал свой лимит: ${usd(key.spent):.2f} из "
                                    f"${usd(key.spend_limit):.2f}. Увеличьте лимит: {errors.KEYS_URL}",
                               "insufficient_quota", "key_limit_reached")
        general = await settings_store.get(s, "general")
        rpm = int(general.get("rate_limit_rpm") or 0)
        if rpm > 0:
            q, t = _rate[key.id], time.monotonic()
            while q and q[0] < t - 60:
                q.popleft()
            if len(q) >= rpm:
                wait = max(1, int(q[0] + 60 - t) + 1)
                raise GatewayError(429, f"Слишком много запросов: не больше {rpm} в минуту на один ключ. "
                                        f"Повторите через {wait} с.", "rate_limit_error", "rate_limit_exceeded",
                                   headers={"Retry-After": str(wait)})
            q.append(t)
        name = body.get("model")
        if not name or not isinstance(name, str):
            raise GatewayError(400, "Не указана модель. Добавьте в запрос поле \"model\", например "
                                    f"\"gpt-4o-mini\". Список моделей: {errors.MODELS_URL}", code="model_required")
        model = (await s.execute(select(Model).where(Model.public_id == name))).scalar_one_or_none()
        if model and model.is_enabled and model.kind not in kinds:
            hint = "/v1/embeddings" if model.kind == "embedding" else "/v1/chat/completions"
            raise GatewayError(400, f"Модель «{name}» нельзя использовать в {request.url.path}. "
                                    f"Отправьте запрос на {hint}.", code="wrong_endpoint")
        if model and not model.is_enabled:
            raise GatewayError(404, f"Модель «{name}» временно отключена. Выберите другую: {errors.MODELS_URL}",
                               code="model_disabled")
        if not model:
            ids = (await s.execute(select(Model.public_id).where(Model.is_enabled == True,
                                                                 Model.kind.in_(kinds)))).scalars().all()
            raise GatewayError(404, errors.model_not_found(name, list(ids)), "invalid_request_error",
                               "model_not_found")
        markup = user.markup if user.markup is not None else general.get("default_markup", 0)
        return Ctx(user, key, model, markup, "req_" + secrets.token_hex(12), client_ip(request), endpoint)


async def candidates(model: Model, types=None):
    """Ordered (route, provider, key_id, secret) list honoring route priority, provider state and key rotation."""
    out = []
    async with SessionLocal() as s:
        for route in sorted(model.routes, key=lambda r: r.priority):
            p = await s.get(Provider, route.provider_id)
            if not p or not p.is_enabled or (types and p.type not in types):
                continue
            t = now()
            keys = [k for k in p.keys if k.is_enabled and (k.status == "active" or
                    (k.status == "paused" and (k.paused_until is None or k.paused_until <= t)))]
            if not keys:
                continue
            start = _rr[p.id] % len(keys)
            _rr[p.id] += 1
            for k in keys[start:] + keys[:start]:
                out.append((route, p, k.id, decrypt(k.key_enc)))
    return out[:MAX_ATTEMPTS]


async def mark_key(key_id: int, status: str, error: str, pause_seconds: int = 0):
    async with SessionLocal() as s:
        vals = {"status": status, "last_error": error[:1000]}
        if pause_seconds:
            vals["paused_until"] = now() + dt.timedelta(seconds=pause_seconds)
        await s.execute(update(ProviderKey).where(ProviderKey.id == key_id).values(**vals))
        await s.commit()


async def mark_key_ok(key_id: int):
    async with SessionLocal() as s:
        await s.execute(update(ProviderKey).where(ProviderKey.id == key_id, ProviderKey.status == "paused")
                        .values(status="active", paused_until=None))
        await s.commit()


def upstream_headers(p: Provider, secret: str) -> dict:
    if p.type == "anthropic":
        h = {"x-api-key": secret, "anthropic-version": "2023-06-01"}
    else:
        h = {"Authorization": f"Bearer {secret}"}
    try:
        h.update(json.loads(p.extra_headers or "{}"))
    except json.JSONDecodeError:
        pass
    return h


async def send_with_fallback(ctx: Ctx, cands, build):
    """Try candidates in order. build(route, provider) -> (url, payload). Returns (resp, route, provider, key_id, n)."""
    if not cands:
        raise GatewayError(503, f"Модель {ctx.model.public_id} сейчас недоступна. Попробуйте позже или выберите "
                                f"другую модель: {errors.MODELS_URL}", "api_error", "no_providers")
    last = "unknown error"
    last_status = 502
    for n, (route, p, key_id, secret) in enumerate(cands, 1):
        url, payload = build(route, p)
        try:
            req = http.build_request("POST", url, json=payload, headers=upstream_headers(p, secret),
                                     timeout=httpx.Timeout(p.timeout, connect=15))
            resp = await http.send(req, stream=True)
        except httpx.HTTPError as e:
            last = f"{p.name}: {type(e).__name__} {e}"
            await mark_key(key_id, "paused", last, 30)
            continue
        if resp.status_code < 400:
            await mark_key_ok(key_id)
            return resp, route, p, key_id, n
        text = (await resp.aread()).decode(errors="replace")[:1500]
        await resp.aclose()
        last, last_status = f"{p.name} HTTP {resp.status_code}: {text}", resp.status_code
        if resp.status_code in (401, 403):
            await mark_key(key_id, "error", last)
        elif resp.status_code == 429 or "quota" in text.lower() or "credit balance" in text.lower():
            await mark_key(key_id, "paused", last, 60)
        elif resp.status_code in (400, 413, 422):
            # client's fault: don't fall back, return provider message (without leaking provider identity)
            msg = text
            try:
                j = json.loads(text)
                msg = (j.get("error") or {}).get("message") or text
            except Exception:
                pass
            await record(**ctx.bill_kwargs(p.id, key_id, 0, 0, False, resp.status_code, last, n))
            raise GatewayError(resp.status_code, errors.upstream_bad_request(str(msg), ctx.model),
                               "invalid_request_error", "upstream_bad_request")
    await record(**ctx.bill_kwargs(None, None, 0, 0, False, 502, last, len(cands)))
    raise GatewayError(502, f"Модель {ctx.model.public_id} временно не отвечает. Повторите запрос через минуту "
                            "или выберите другую модель.", "api_error", "upstream_unavailable",
                       headers={"Retry-After": "30"})


def sse(obj) -> bytes:
    return f"data: {json.dumps(obj, ensure_ascii=False)}\n\n".encode()


async def iter_sse_data(resp):
    async for line in resp.aiter_lines():
        if line.startswith("data:"):
            yield line[5:].strip()


# --------------------------------------------------------------------------- /v1/chat/completions
@router.post("/chat/completions")
async def chat_completions(request: Request):
    rid = ""
    try:
        body = await read_body(request)
        ctx = await resolve(request, body, "chat")
        check_messages(body)
        rid = ctx.rid
        stream = bool(body.get("stream"))
        want_usage = bool((body.get("stream_options") or {}).get("include_usage"))
        cands = await candidates(ctx.model)

        def build(route, p):
            base = p.base_url.rstrip("/")
            if p.type == "anthropic":
                return base + "/messages", openai_to_anthropic(body, route.upstream_model, ctx.model.max_output)
            payload = dict(body)
            payload["model"] = route.upstream_model
            if stream:
                payload["stream_options"] = {"include_usage": True}
            return base + "/chat/completions", payload

        resp, route, p, key_id, n = await send_with_fallback(ctx, cands, build)
    except GatewayError as e:
        return error_response(e, rid)
    except json.JSONDecodeError:
        return error_response(GatewayError(400, BAD_JSON, code="invalid_json"))

    prompt_est = estimate_tokens(json.dumps(body.get("messages", []), ensure_ascii=False))

    if not stream:
        try:
            data = json.loads(await resp.aread())
        finally:
            await resp.aclose()
        if p.type == "anthropic":
            data = anthropic_to_openai(data, ctx.model.public_id)
        else:
            data["model"] = ctx.model.public_id
        u = data.get("usage") or {}
        tin = u.get("prompt_tokens") or prompt_est
        tout = u.get("completion_tokens") or 0
        await record(**ctx.bill_kwargs(p.id, key_id, tin, tout, False, attempts=n))
        return JSONResponse(data, headers=ctx.headers(tin, tout))

    async def gen():
        tin, tout, chars, got_usage = 0, 0, 0, False
        conv = AnthropicStreamToOpenAI(ctx.model.public_id, want_usage) if p.type == "anthropic" else None
        status, err = 200, ""
        try:
            async for data in iter_sse_data(resp):
                if not data:
                    continue
                if data == "[DONE]":
                    if conv is None:
                        yield b"data: [DONE]\n\n"
                    continue
                try:
                    obj = json.loads(data)
                except json.JSONDecodeError:
                    continue
                if conv is not None:
                    for ch in conv.feed(obj):
                        yield sse(ch)
                    tin, tout, chars = conv.prompt_tokens, conv.completion_tokens, conv.text_chars
                    got_usage = conv.completion_tokens > 0
                    if conv.done:
                        yield b"data: [DONE]\n\n"
                    continue
                if obj.get("usage"):
                    tin = obj["usage"].get("prompt_tokens") or tin
                    tout = obj["usage"].get("completion_tokens") or tout
                    got_usage = True
                for c in obj.get("choices") or []:
                    d = c.get("delta") or {}
                    chars += len(d.get("content") or "") + len(d.get("reasoning_content") or "")
                    for tc in d.get("tool_calls") or []:
                        chars += len((tc.get("function") or {}).get("arguments") or "")
                if "model" in obj:
                    obj["model"] = ctx.model.public_id
                if not obj.get("choices") and obj.get("usage") and not want_usage:
                    continue
                yield sse(obj)
        except Exception as e:  # upstream broke mid-stream
            status, err = 200, f"stream interrupted: {type(e).__name__}"
        finally:
            if not got_usage:
                tin = tin or prompt_est
                tout = tout or estimate_tokens("x" * chars)
            record_bg(**ctx.bill_kwargs(p.id, key_id, tin or prompt_est, tout, True, status, err, n))
            try:
                await resp.aclose()
            except Exception:
                pass

    return StreamingResponse(gen(), media_type="text/event-stream",
                             headers={**ctx.headers(), "Cache-Control": "no-cache", "X-Accel-Buffering": "no"})


# --------------------------------------------------------------------------- /v1/messages (Anthropic)
@router.post("/messages")
async def messages(request: Request):
    rid = ""
    try:
        body = await read_body(request)
        ctx = await resolve(request, body, "messages")
        check_messages(body)
        rid = ctx.rid
        cands = await candidates(ctx.model, types=("anthropic",))
        if not cands:
            raise GatewayError(400, f"Модель {ctx.model.public_id} не работает в формате Anthropic (/v1/messages). "
                                    "Используйте /v1/chat/completions.", "invalid_request_error", "wrong_endpoint")

        def build(route, p):
            payload = dict(body)
            payload["model"] = route.upstream_model
            return p.base_url.rstrip("/") + "/messages", payload

        resp, route, p, key_id, n = await send_with_fallback(ctx, cands, build)
    except GatewayError as e:
        return error_response(e, rid, anthropic=True)
    except json.JSONDecodeError:
        return error_response(GatewayError(400, "Тело запроса должно быть JSON"), anthropic=True)

    if not body.get("stream"):
        try:
            data = json.loads(await resp.aread())
        finally:
            await resp.aclose()
        data["model"] = ctx.model.public_id
        tin, tout = anthropic_usage(data.get("usage"))
        await record(**ctx.bill_kwargs(p.id, key_id, tin, tout, False, attempts=n))
        return JSONResponse(data, headers=ctx.headers(tin, tout))

    async def gen():
        tin = tout = 0
        try:
            async for line in resp.aiter_lines():
                if line.startswith("data:"):
                    try:
                        ev = json.loads(line[5:])
                        if ev.get("type") == "message_start":
                            ev["message"]["model"] = ctx.model.public_id
                            tin, tout = anthropic_usage(ev["message"].get("usage"))
                            line = "data: " + json.dumps(ev, ensure_ascii=False)
                        elif ev.get("type") == "message_delta":
                            tout = (ev.get("usage") or {}).get("output_tokens") or tout
                    except Exception:
                        pass
                yield (line + "\n").encode()
        finally:
            record_bg(**ctx.bill_kwargs(p.id, key_id, tin, tout, True, attempts=n))
            try:
                await resp.aclose()
            except Exception:
                pass

    return StreamingResponse(gen(), media_type="text/event-stream",
                             headers={**ctx.headers(), "Cache-Control": "no-cache", "X-Accel-Buffering": "no"})


# --------------------------------------------------------------------------- /v1/embeddings
@router.post("/embeddings")
async def embeddings(request: Request):
    rid = ""
    try:
        body = await read_body(request)
        ctx = await resolve(request, body, "embeddings", kinds=("embedding",))
        rid = ctx.rid
        cands = await candidates(ctx.model, types=("openai", "openai_compatible"))

        def build(route, p):
            payload = dict(body)
            payload["model"] = route.upstream_model
            return p.base_url.rstrip("/") + "/embeddings", payload

        resp, route, p, key_id, n = await send_with_fallback(ctx, cands, build)
    except GatewayError as e:
        return error_response(e, rid)
    try:
        data = json.loads(await resp.aread())
    finally:
        await resp.aclose()
    data["model"] = ctx.model.public_id
    tin = (data.get("usage") or {}).get("prompt_tokens") or 0
    await record(**ctx.bill_kwargs(p.id, key_id, tin, 0, False, attempts=n))
    return JSONResponse(data, headers=ctx.headers(tin, 0))


# --------------------------------------------------------------------------- /v1/models, /v1/balance
@router.get("/models")
async def list_models():
    async with SessionLocal() as s:
        rows = (await s.execute(select(Model).where(Model.is_enabled == True).order_by(Model.public_id))).scalars()
        data = [{"id": m.public_id, "object": "model", "created": int(m.created_at.timestamp()),
                 "owned_by": m.family or "gateway", "context_length": m.context_length} for m in rows]
    return {"object": "list", "data": data}


@router.get("/balance")
async def balance(request: Request):
    auth = request.headers.get("authorization", "")
    raw = auth[7:].strip() if auth.lower().startswith("bearer ") else request.headers.get("x-api-key", "")
    async with SessionLocal() as s:
        key = (await s.execute(select(ApiKey).where(ApiKey.key_hash == hash_key(raw)))).scalar_one_or_none()
        if not key:
            return error_response(GatewayError(401, "API-ключ не найден. Создайте ключ: " + errors.KEYS_URL,
                                               "authentication_error", "invalid_api_key"))
        user = await s.get(User, key.user_id)
        return {"balance_usd": usd(user.balance), "key_spent_usd": usd(key.spent),
                "key_limit_usd": usd(key.spend_limit) if key.spend_limit is not None else None}
