// Premier — мониторинг: журнал ошибок (последние 200, видны в /panelp → Обзор), оповещения в Telegram или на свой адрес,
// проверка «жив ли сервер» (GET /healthz). Внешних сервисов не нужно.
//   ALERT_TELEGRAM_TOKEN + ALERT_TELEGRAM_CHAT — бот и чат для оповещений; ALERT_WEBHOOK_URL — POST JSON {text} на свой адрес
const os = require('os');
const started = Date.now(), errors = [], counts = { req: 0, e5xx: 0 };
const TG = process.env.ALERT_TELEGRAM_TOKEN, TG_CHAT = process.env.ALERT_TELEGRAM_CHAT, HOOK = process.env.ALERT_WEBHOOK_URL;
const NAME = process.env.ALERT_NAME || os.hostname();
const sent = new Map(); let sentHour = 0, hourAt = 0;
const chats = [];
function chat(record) {
  // Без сообщений, reasoning, ключей и URL провайдера.
  const safe = {};
  for (const key of ['id', 'model', 'intent', 'artifactMode', 'baseHash', 'editCount', 'ms', 'firstTextMs', 'requests', 'repairs', 'tools', 'outcome'])
    if (record[key] !== undefined) safe[key] = record[key];
  chats.push({ at: Date.now(), ...safe }); if (chats.length > 100) chats.shift();
  console.log('[чат] ' + JSON.stringify(safe));
}

// ошибка в коде (а не «неверный пароль» и т. п.): такие стоит чинить
const isBug = (e) => !!e && !e.status && (e instanceof TypeError || e instanceof ReferenceError || e instanceof RangeError || e instanceof SyntaxError && !/JSON/.test(e.message) || /^ERR_SQLITE/.test(e.code || '') || /database is locked|disk I\/O|SQLITE_/i.test(e.message || ''));

function alert(text) {
  if (!TG && !HOOK) return;
  const key = text.slice(0, 160), now = Date.now();
  if (sent.get(key) > now - 10 * 60e3) return; // одно и то же — не чаще раза в 10 минут
  if (now - hourAt > 3600e3) { hourAt = now; sentHour = 0; } if (++sentHour > 20) return; // и не больше 20 в час
  sent.set(key, now); if (sent.size > 500) sent.clear();
  const msg = `⚠️ Premier (${NAME})\n${text}`.slice(0, 3500);
  const go = (url, body) => fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body), signal: AbortSignal.timeout(10000) }).catch(() => {});
  if (TG && TG_CHAT) go(`https://api.telegram.org/bot${TG}/sendMessage`, { chat_id: TG_CHAT, text: msg, disable_web_page_preview: true });
  if (HOOK) go(HOOK, { text: msg });
}
function error(where, e, extra) {
  const msg = String(e && e.message || e).slice(0, 500), stack = String(e && e.stack || '').split('\n').slice(1, 4).map((s) => s.trim()).join(' ← ').slice(0, 600);
  const last = errors[errors.length - 1];
  if (last && last.where === where && last.msg === msg && Date.now() - last.at < 60e3) last.n++;
  else { errors.push({ at: Date.now(), where: String(where).slice(0, 120), msg, stack, n: 1, ...(extra ? { extra: String(extra).slice(0, 200) } : {}) }); if (errors.length > 200) errors.shift(); }
  console.error(`[ошибка] ${where}: ${msg}${stack ? '\n  ' + stack : ''}`);
  alert(`${where}: ${msg}`);
}
const request = (status) => { counts.req++; if (status >= 500) counts.e5xx++; };
const list = () => errors.slice().reverse();
const day = () => errors.filter((x) => x.at > Date.now() - 864e5).reduce((n, x) => n + x.n, 0);
function health(checks = {}) {
  const res = { ok: true, uptime: Math.round((Date.now() - started) / 1000) }, det = {};
  for (const [k, fn] of Object.entries(checks)) { try { det[k] = fn(); if (det[k] === false) res.ok = false; } catch (e) { det[k] = false; res.ok = false; } }
  return { ...res, checks: det };
}
function stats() {
  const m = process.memoryUsage();
  return { uptime: Math.round((Date.now() - started) / 1000), rssMb: Math.round(m.rss / 1048576), heapMb: Math.round(m.heapUsed / 1048576), load: os.loadavg()[0], freeMb: Math.round(os.freemem() / 1048576), requests: counts.req, e5xx: counts.e5xx, errors24h: day(), alerts: !!(TG && TG_CHAT) || !!HOOK };
}
// падение процесса: записать, оповестить и дать systemd перезапустить сервис
let installed = false;
function install() {
  if (installed) return; installed = true;
  process.on('unhandledRejection', (e) => error('необработанная ошибка (promise)', e));
  process.on('uncaughtException', (e) => { error('сервер упал', e); setTimeout(() => process.exit(1), 1500).unref(); });
}
module.exports = { error, isBug, alert, request, list, health, stats, install, chat, chats: () => chats.slice().reverse() };
