"""Fake OpenAI + Anthropic upstreams for e2e tests."""
import json
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse, StreamingResponse

app = FastAPI()
FAIL = {"n": 0}


@app.get("/oa/v1/models")
async def oa_models():
    return {"data": [{"id": "gpt-4o-mini"}, {"id": "gpt-4o"}, {"id": "text-embedding-3-small"}, {"id": "weird-model"}]}


@app.get("/bad/v1/models")
async def bad_models():
    return JSONResponse({"error": {"message": "invalid key"}}, 401)


@app.post("/bad/v1/chat/completions")
async def bad_chat():
    return JSONResponse({"error": {"message": "server down"}}, 500)


@app.post("/oa/v1/chat/completions")
async def oa_chat(req: Request):
    b = await req.json()
    assert req.headers["authorization"].startswith("Bearer sk-up")
    if b.get("stream"):
        async def g():
            for w in ["Привет", ", ", "мир"]:
                yield f'data: {json.dumps({"id":"x","object":"chat.completion.chunk","model":b["model"],"choices":[{"index":0,"delta":{"content":w},"finish_reason":None}]})}\n\n'
            yield f'data: {json.dumps({"id":"x","object":"chat.completion.chunk","model":b["model"],"choices":[{"index":0,"delta":{},"finish_reason":"stop"}]})}\n\n'
            if (b.get("stream_options") or {}).get("include_usage"):
                yield f'data: {json.dumps({"id":"x","object":"chat.completion.chunk","model":b["model"],"choices":[],"usage":{"prompt_tokens":10,"completion_tokens":3,"total_tokens":13}})}\n\n'
            yield "data: [DONE]\n\n"
        return StreamingResponse(g(), media_type="text/event-stream")
    return {"id": "x", "object": "chat.completion", "model": b["model"],
            "choices": [{"index": 0, "message": {"role": "assistant", "content": "ok:" + b["model"]}, "finish_reason": "stop"}],
            "usage": {"prompt_tokens": 1000, "completion_tokens": 500, "total_tokens": 1500}}


@app.post("/oa/v1/embeddings")
async def oa_emb(req: Request):
    return {"object": "list", "data": [{"embedding": [0.1, 0.2], "index": 0}], "model": "x", "usage": {"prompt_tokens": 7, "total_tokens": 7}}


@app.get("/an/v1/models")
async def an_models():
    return {"data": [{"id": "claude-sonnet-4-5-20250929", "display_name": "Claude Sonnet 4.5"}]}


@app.post("/an/v1/messages")
async def an_messages(req: Request):
    b = await req.json()
    assert req.headers["x-api-key"] == "sk-up-anthropic"
    assert all(m["role"] in ("user", "assistant") for m in b["messages"])
    if b.get("stream"):
        evs = [{"type": "message_start", "message": {"id": "msg1", "model": b["model"], "usage": {"input_tokens": 20, "output_tokens": 1}}},
               {"type": "content_block_start", "index": 0, "content_block": {"type": "text", "text": ""}},
               {"type": "content_block_delta", "index": 0, "delta": {"type": "text_delta", "text": "Hello"}},
               {"type": "content_block_delta", "index": 0, "delta": {"type": "text_delta", "text": " world"}},
               {"type": "content_block_stop", "index": 0},
               {"type": "message_delta", "delta": {"stop_reason": "end_turn"}, "usage": {"output_tokens": 5}},
               {"type": "message_stop"}]
        async def g():
            for e in evs:
                yield f"event: {e['type']}\ndata: {json.dumps(e)}\n\n"
        return StreamingResponse(g(), media_type="text/event-stream")
    content = [{"type": "text", "text": "sys=" + str(b.get("system"))}]
    if b.get("tools"):
        content.append({"type": "tool_use", "id": "toolu_1", "name": b["tools"][0]["name"], "input": {"city": "Moscow"}})
    return {"id": "msg1", "type": "message", "role": "assistant", "model": b["model"], "content": content,
            "stop_reason": "tool_use" if b.get("tools") else "end_turn", "usage": {"input_tokens": 2000, "output_tokens": 1000}}
