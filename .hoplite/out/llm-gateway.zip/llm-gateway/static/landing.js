/* Public landing (#/, #/login, #/register).
   Order: hero with a real request · prices (live from /api/public/models) · connect · billing · status · FAQ. */
'use strict';
const LP = {};
const LP_EX = { pin: 1200, pout: 400 }; // tokens used in the worked example
// Volume calculator: the slider is continuous but logarithmic, otherwise 500K–5M would fit into the first 5% of the track.
const LP_VOL = { min: 5e5, max: 1e8, steps: 1000, ticks: [5e5, 1e6, 5e6, 1e7, 5e7, 1e8] };
const LP_MIX = [['Чат-бот', 3, 1], ['Документы', 10, 1], ['Генерация', 1, 3]]; // label, input : output

function landingPage(el, p, q, { login = false } = {}) {
  LP.vol = LP.vol || 1e7; LP.mix = LP.mix || 0; // kept across language re-renders
  const cfg = S.cfg, stOn = cfg.status_page !== false, host = location.origin;
  const nav = [['prices', 'Цены'], ['connect', 'Подключение'], ['pay', 'Оплата']].concat(stOn ? [['status', 'Статус']] : [], [['faq', 'Вопросы']]);
  const brand = `<a class="brand lp-brand" href="#/" data-go="top"><div class="logo">${LOGO}</div><span>${esc(cfg.site_name)}</span></a>`;
  el.innerHTML = `<div class="lp" id="lp">
  <header class="lp-top" id="lpTop"><div class="lp-w lp-top-in">
    ${brand}
    <nav class="lp-nav">${nav.map(([id, t]) => `<a href="#/" data-go="${id}">${t}</a>`).join('')}</nav>
    <div class="row lp-act">${langSw()}<button class="btn sm icon ghost" id="lpTh" title="Тема">${ic(document.documentElement.dataset.theme === 'dark' ? 'sun' : 'moon')}</button><button class="btn sm" data-login>Войти</button></div>
  </div></header>

  <section class="lp-hero" data-sec="top"><div class="lp-w lp-hero-in">
    <div class="lp-hero-l">
      <h1 class="lp-h1">GPT, Claude, Gemini и DeepSeek через один API-ключ</h1>
      <p class="lp-lead">Замените <code>base_url</code> в своём коде, и все модели каталога станут доступны через OpenAI-совместимый API. Баланс пополняется через СБП, картой или криптовалютой. Списание идёт по фактическим токенам.</p>
      <div class="row wrap lp-cta"><button class="btn pri lg" data-login>Получить ключ</button><a class="lp-more" href="#/" data-go="prices">Посмотреть цены</a></div>
      <dl class="lp-facts" id="lpFacts">${lpFacts(null)}</dl>
    </div>
    <div class="lp-hero-r">${lpReq(host, null)}</div>
  </div></section>

  <section class="lp-sec" data-sec="prices"><div class="lp-w">
    <div class="lp-sh"><h2>Цены</h2><p>Цена указана за 1 млн токенов, отдельно для входа и выхода. Списываем по полю <code>usage</code> из ответа модели, без округлений до тысяч.</p></div>
    <div class="lp-vol" id="lpVol">${lpVolBox()}</div>
    <div class="lp-pr-bar"><input class="inp" id="lpQ" type="search" placeholder="Поиск по названию модели" autocomplete="off"><span class="small dim" id="lpCnt"></span></div>
    <div class="tbl-wrap lp-pr" id="lpPr">${lpPriceSkel()}</div>
  </div></section>

  <section class="lp-sec" data-sec="connect"><div class="lp-w lp-split">
    <div>
      <div class="lp-sh"><h2>Подключение</h2><p>Шлюз повторяет OpenAI API, поэтому официальные SDK, LangChain и IDE-ассистенты работают без доработок. Нужно поменять адрес и ключ.</p></div>
      <ul class="lp-list">
        <li>Стриминг, вызов инструментов и JSON-режим работают так же, как у OpenAI.</li>
        <li>Для клиентов Anthropic есть отдельный совместимый эндпоинт.</li>
        <li>Если у модели несколько провайдеров, при сбое запрос уходит на другой.</li>
      </ul>
    </div>
    <div class="lp-code" data-noi18n>${lpCode(host)}</div>
  </div></section>

  <section class="lp-sec" data-sec="pay"><div class="lp-w lp-split">
    <div>
      <div class="lp-sh"><h2>Оплата</h2></div>
      <dl class="lp-rows">
        <div><dt>Способы</dt><dd>СБП, банковские карты, криптовалюта.</dd></div>
        <div><dt>Списание</dt><dd>За фактические токены каждого запроса по тарифу модели. Подписки и абонентской платы нет.</dd></div>
        <div><dt>Контроль</dt><dd>Лимит трат на каждый ключ, история запросов и расходы по дням в кабинете.</dd></div>
      </dl>
    </div>
    <div class="lp-calc" id="lpCalc">${lpCalc(null)}</div>
  </div></section>

  ${stOn ? `<section class="lp-sec" data-sec="status"><div class="lp-w">
    <div class="lp-sh lp-sh-row"><div><h2>Статус</h2><p>Данные за последние 24 часа, обновляются раз в минуту.</p></div><a class="lp-more" href="#/status">Подробная страница</a></div>
    <div id="lpSt">${lpStatusSkel()}</div></div></section>` : ''}

  <section class="lp-sec" data-sec="faq"><div class="lp-w">
    <div class="lp-sh"><h2>Вопросы</h2></div>
    <dl class="lp-faq">${[
      ['Нужно ли менять код?', 'Нет. Достаточно заменить адрес API и ключ. Подходят официальные SDK OpenAI и любые инструменты, где можно указать свой адрес.'],
      ['Как считается стоимость запроса?', 'Число входных и выходных токенов умножается на тариф модели. Стоимость каждого запроса видна в истории в кабинете.'],
      ['Можно ли ограничить расходы?', 'Да, для каждого ключа задаётся лимит. Когда он исчерпан, этот ключ перестаёт принимать запросы, остальные работают дальше.'],
      ['Что будет, если модель недоступна?', 'Если у модели несколько провайдеров, запрос автоматически уйдёт на работающий. Текущее состояние видно в разделе «Статус».'],
      ['Какие модели принимают изображения?', 'Те, у которых в таблице цен указано «изображения». Вызов инструментов отмечен там же.'],
      ['Нужен ли отдельный баланс для каждого ключа?', 'Нет, баланс один на все ключи и модели.'],
    ].map(([qq, a]) => `<div><dt>${qq}</dt><dd>${a}</dd></div>`).join('')}</dl>
  </div></section>

  <footer class="lp-foot"><div class="lp-w lp-foot-in">
    <div class="lp-foot-b">${brand}<p class="small muted">OpenAI-совместимый доступ к языковым моделям с оплатой по токенам.</p></div>
    <div><div class="lp-foot-h">Сервис</div><a href="#/" data-go="prices">Цены</a><a href="#/" data-go="connect">Подключение</a>${stOn ? '<a href="#/status">Статус</a>' : ''}<a href="#/" data-login>Войти</a></div>
    <div><div class="lp-foot-h">Документы</div><a href="/privacy">Политика конфиденциальности</a><a href="/terms">Пользовательское соглашение</a></div>
    <div><div class="lp-foot-h">Поддержка</div>${cfg.support_contact ? `<span data-noi18n>${esc(cfg.support_contact)}</span>` : '<span class="dim">Контакт появится здесь</span>'}<a href="#/" data-go="faq">Вопросы и ответы</a></div>
  </div><div class="lp-w"><div class="lp-foot-c small dim">© ${new Date().getFullYear()} ${esc(cfg.site_name)}</div></div></footer></div>`;

  const root = $('#lp');
  root.addEventListener('click', e => {
    const g = e.target.closest('[data-go]'); if (g) { e.preventDefault(); lpGo(g.dataset.go); return; }
    const l = e.target.closest('[data-login]'); if (l) { e.preventDefault(); lpLogin({}); return; }
    const m = e.target.closest('[data-more]'); if (m) { LP.all = true; lpPrices(); return; }
    const v = e.target.closest('[data-vol]'); if (v) { LP.vol = +v.dataset.vol; $('#lpRng').value = lpPosOf(LP.vol); lpVolUpd(); return; }
    const x = e.target.closest('[data-mix]'); if (x) { LP.mix = +x.dataset.mix; $$('[data-mix]', root).forEach(b => b.classList.toggle('on', b === x)); lpPrices(); lpVolUpd(); }
  });
  $('#lpRng').oninput = e => { LP.vol = lpVolAt(+e.target.value); lpVolUpd(); };
  $('#lpTh').onclick = e => themeSwitch(e.currentTarget);
  const top = $('#lpTop'), links = $$('.lp-nav a', root), secs = $$('[data-sec]', root);
  const onScroll = () => { if (!top.isConnected) return removeEventListener('scroll', onScroll);
    top.classList.toggle('scrolled', scrollY > 8);
    let cur = ''; for (const s of secs) if (s.getBoundingClientRect().top < innerHeight * .35) cur = s.dataset.sec;
    links.forEach(a => a.classList.toggle('on', a.dataset.go === cur)); };
  addEventListener('scroll', onScroll, { passive: true }); onScroll();
  lpTabs($('.lp-code', root));
  $('#lpQ').oninput = e => { LP.q = e.target.value.trim().toLowerCase(); lpPrices(); };
  LP.q = ''; LP.all = false; LP.models = null; LP.st = null;
  lpLoadModels(host);
  lpVolUpd();
  if (stOn) lpStatus();
  if (login) lpLogin(q);
}

// ---------- data
const lpPick = ms => ms.find(m => m.popular && m.kind !== 'image') || ms.find(m => m.kind !== 'image' && m.price_in > 0) || ms[0];
const lpRate = () => (typeof S !== 'undefined' && S.cfg && +S.cfg.usd_rub_rate) || 95;
const lpUsd = (v, d = 2) => { const x = Number(v || 0) * lpRate();
  return (Math.abs(x - Math.round(x)) < 0.005 ? Math.round(x) : x).toLocaleString('ru-RU', { minimumFractionDigits: 0, maximumFractionDigits: d }) + ' ₽'; };
async function lpLoadModels(host) {
  let ms; try { ms = await api('/api/public/models'); } catch { ms = []; }
  if (!$('#lpPr')) return;
  LP.models = ms.filter(m => m.kind !== 'embedding' || m.price_in > 0);
  const ex = LP.models.length ? lpPick(LP.models) : null;
  $('#lpFacts').innerHTML = lpFacts(LP.models);
  $('.lp-hero-r').innerHTML = lpReq(host, ex);
  $('#lpCalc').innerHTML = lpCalc(ex);
  lpPrices(); lpVolUpd();
}
function lpFacts(ms) {
  const items = [];
  if (ms && ms.length) {
    const priced = ms.filter(m => m.price_in > 0);
    items.push(['Моделей в каталоге', nf(ms.length)]);
    if (priced.length) items.push(['Вход, от', `${lpUsd(Math.min(...priced.map(m => m.price_in)))} / 1M`]);
  } else items.push(['Моделей в каталоге', '—']);
  items.push(['Абонентская плата', '0 ₽']);
  return items.map(([k, v]) => `<div><dt>${k}</dt><dd class="num">${v}</dd></div>`).join('');
}

// ---------- hero: a real request and what it costs
function lpReq(host, m) {
  const id = m ? m.id : 'gpt-4o-mini';
  const cost = m ? (LP_EX.pin * m.price_in + LP_EX.pout * m.price_out) / 1e6 : null;
  const s = t => `<span class="tk-s">${esc(t)}</span>`, k = t => `<span class="tk-k">${esc(t)}</span>`, c = t => `<span class="tk-c">${esc(t)}</span>`;
  return `<div class="lp-req" data-noi18n>
    <div class="lp-req-h"><span class="mono">POST /v1/chat/completions</span><span class="lp-req-st">200 OK</span></div>
    <pre class="lp-req-b">{
  ${k('"model"')}: ${s(`"${id}"`)},
  ${k('"messages"')}: [
    { ${k('"role"')}: ${s('"user"')}, ${k('"content"')}: ${s(`"${I18N.t('Сократи текст договора до 5 пунктов')}"`)} }
  ]
}</pre>
    <div class="lp-req-sep">${c(I18N.t('ответ, фрагмент'))}</div>
    <pre class="lp-req-b">${k('"usage"')}: {
  ${k('"prompt_tokens"')}: ${nf(LP_EX.pin).replace(/\s/g, '')},
  ${k('"completion_tokens"')}: ${LP_EX.pout}
}</pre>
    <div class="lp-req-f"><span>${I18N.t('Списано с баланса')}</span><b class="num">${cost == null ? '—' : lpUsd(cost)}</b></div>
  </div>`;
}

// ---------- prices table
const lpPriceSkel = () => `<table><tbody>${'<tr><td colspan="6"><div class="skel" style="height:16px"></div></td></tr>'.repeat(6)}</tbody></table>`;
function lpCaps(m) {
  const c = [];
  if (m.vision) c.push('изображения'); if (m.tools) c.push('инструменты');
  if (m.kind === 'image') c.push('генерация изображений'); if (m.kind === 'embedding') c.push('эмбеддинги');
  return c.join(', ') || '—';
}
const lpCtx = n => !n ? '—' : n >= 1e6 ? String(Math.round(n / 1e5) / 10).replace('.', I18N.lang === 'ru' ? ',' : '.') + 'M' : Math.round(n / 1e3) + 'K';
function lpPrices() {
  const box = $('#lpPr'); if (!box || !LP.models) return;
  const all = LP.models.slice().sort((a, b) => (b.popular - a.popular) || String(a.family || '').localeCompare(String(b.family || '')) || a.id.localeCompare(b.id));
  const f = LP.q ? all.filter(m => (m.id + ' ' + (m.name || '') + ' ' + (m.family || '')).toLowerCase().includes(LP.q)) : all;
  const LIM = 12, rows = LP.rows = LP.all || LP.q ? f : f.slice(0, LIM), best = lpBest();
  $('#lpCnt').textContent = LP.models.length ? `${f.length} / ${LP.models.length}` : '';
  if (!LP.models.length) { box.innerHTML = `<div class="lp-empty">Каталог пока пуст. Модели появятся здесь, когда администратор их включит.</div>`; return; }
  if (!f.length) { box.innerHTML = `<div class="lp-empty">Ничего не найдено по запросу «${esc(LP.q)}».</div>`; return; }
  box.innerHTML = `<table><thead><tr><th>Модель</th><th class="r">Контекст</th><th class="r">Вход, ₽/1M</th><th class="r">Выход, ₽/1M</th><th class="r lp-vc" id="lpVolH" data-noi18n>${lpVolHead()}</th><th>Возможности</th></tr></thead><tbody>
    ${rows.map((m, i) => `<tr><td><div class="lp-mrow">${modelLogo(m, 1)}<div class="lp-mn"><b data-noi18n>${esc(m.name || m.id)}</b>${m.name && m.name !== m.id ? `<span class="mono dim" data-noi18n>${esc(m.id)}</span>` : ''}</div></div></td>
      <td class="r num">${lpCtx(m.context_length)}</td><td class="r num">${m.price_in ? lpUsd(m.price_in) : '—'}</td><td class="r num">${m.price_out ? lpUsd(m.price_out) : '—'}</td>
      <td class="r num lp-vc" data-ci="${i}">${best && best.m === m ? '<span class="badge ok">дешевле всех</span>' : ''}<span>${lpSum(lpCost(m))}</span></td><td class="muted">${lpCaps(m)}</td></tr>`).join('')}
  </tbody></table>${rows.length < f.length ? `<button class="lp-all" data-more>Показать все модели (${f.length})</button>` : ''}`;
}

// ---------- volume calculator: tokens per month × input/output mix → cost of every model
const lpVolAt = p => { const v = LP_VOL.min * (LP_VOL.max / LP_VOL.min) ** (p / LP_VOL.steps), e = 10 ** (Math.floor(Math.log10(v)) - 2);
  return Math.round(v / e) * e; }; // 3 significant digits: smooth to drag, still readable
const lpPosOf = v => Math.round(Math.log(v / LP_VOL.min) / Math.log(LP_VOL.max / LP_VOL.min) * LP_VOL.steps);
function lpTok(n, short) { // 12 300 000 → «12,3 млн» / «12.3M»
  n = +Number(n).toPrecision(3);
  const M = n >= 1e6, v = (n / (M ? 1e6 : 1e3)).toLocaleString(I18N.locale(), { maximumFractionDigits: 2 });
  return short || I18N.lang === 'en' ? v + (M ? 'M' : 'K') : v + (M ? ' млн' : ' тыс.');
}
const lpVolHead = () => (I18N.lang === 'en' ? 'For ' : 'За ') + lpTok(LP.vol);
function lpCost(m, n = LP.vol) {
  if (m.kind === 'image' || !(m.price_in > 0)) return null;
  if (m.kind === 'embedding') return n * m.price_in / 1e6; // embeddings have no output tokens
  const [, a, b] = LP_MIX[LP.mix];
  return n * (a * m.price_in + b * m.price_out) / (a + b) / 1e6;
}
const lpSum = c => c == null ? '—' : lpUsd(c, c * lpRate() >= 100 ? 0 : 2);
function lpBest() { // the ranking depends only on the mix, not on the volume
  let best = null;
  for (const m of LP.models || []) { if (m.kind === 'embedding') continue;
    const c = lpCost(m); if (c != null && (!best || c < best.c)) best = { m, c }; }
  return best;
}
function lpVolBox() {
  const p = lpPosOf(LP.vol);
  return `<div class="lp-vol-top">
      <div><div class="lp-vol-l">Токенов в месяц</div><div class="lp-vol-v num" id="lpVolV" data-noi18n>${lpTok(LP.vol)}</div></div>
      <div class="lp-vol-mix"><span class="small dim">Тип нагрузки</span><div class="pills" role="group" aria-label="Тип нагрузки">
        ${LP_MIX.map(([t, a, b], i) => `<button type="button" data-mix="${i}" class="${i === LP.mix ? 'on' : ''}">${t} <span class="num" data-noi18n>${a}:${b}</span></button>`).join('')}
      </div></div>
    </div>
    <input type="range" class="lp-rng" id="lpRng" min="0" max="${LP_VOL.steps}" step="1" value="${p}" style="--p:${p / LP_VOL.steps * 100}%" aria-label="Токенов в месяц">
    <div class="lp-ticks" data-noi18n>${LP_VOL.ticks.map(v => `<button type="button" data-vol="${v}" class="${v === 5e7 ? 'opt' : ''}" style="--t:${lpPosOf(v) / LP_VOL.steps}">${lpTok(v, true)}</button>`).join('')}</div>
    <div class="lp-vol-f">
      <span class="muted num" id="lpVolS" data-noi18n></span>
      <div class="lp-vol-best" id="lpVolBest" hidden><span class="dim">Дешевле всех:</span><b id="lpBestN" data-noi18n></b><b class="num" id="lpBestV"></b><button class="btn pri sm" data-login>Получить ключ</button></div>
    </div>`;
}
function lpVolUpd() {
  const rng = $('#lpRng'); if (!rng) return;
  const n = LP.vol, [, a, b] = LP_MIX[LP.mix], en = I18N.lang === 'en', vin = lpTok(n * a / (a + b)), vout = lpTok(n * b / (a + b));
  rng.style.setProperty('--p', rng.value / LP_VOL.steps * 100 + '%');
  rng.setAttribute('aria-valuetext', `${lpTok(n)} ${en ? 'tokens' : 'токенов'}`);
  $('#lpVolV').textContent = lpTok(n);
  $('#lpVolS').textContent = en ? `${vin} input + ${vout} output` : `${vin} входных + ${vout} выходных`;
  const best = lpBest(), bx = $('#lpVolBest');
  bx.hidden = !best;
  if (best) { $('#lpBestN').textContent = best.m.name || best.m.id; $('#lpBestV').textContent = lpSum(best.c); }
  const h = $('#lpVolH'); if (h) h.textContent = lpVolHead();
  $$('#lpPr [data-ci]').forEach(td => { td.lastElementChild.textContent = lpSum(lpCost(LP.rows[+td.dataset.ci])); });
}

// ---------- worked billing example
function lpCalc(m) {
  if (!m || !m.price_in) return `<div class="lp-calc-h">Пример расчёта</div><p class="muted small">Появится, когда в каталоге будут модели с ценами.</p>`;
  const a = LP_EX.pin * m.price_in / 1e6, b = LP_EX.pout * m.price_out / 1e6;
  return `<div class="lp-calc-h">Пример расчёта: <span class="mono" data-noi18n>${esc(m.id)}</span></div>
    <table class="lp-calc-t"><tbody>
      <tr><td>Входные токены</td><td class="r num">${nf(LP_EX.pin)} × ${lpUsd(m.price_in)} / 1M</td><td class="r num">${lpUsd(a)}</td></tr>
      <tr><td>Выходные токены</td><td class="r num">${nf(LP_EX.pout)} × ${lpUsd(m.price_out)} / 1M</td><td class="r num">${lpUsd(b)}</td></tr>
      <tr class="tot"><td>Итого за запрос</td><td></td><td class="r num">${lpUsd(a + b)}</td></tr>
    </tbody></table>
    <p class="small muted">Это та же сумма, которую вы увидите в истории запросов.</p>`;
}

// ---------- code diff with tabs
function lpCode(host) {
  const s = t => `<span class="tk-s">${esc(t)}</span>`, k = t => `<span class="tk-k">${t}</span>`;
  const tabs = {
    'Python': [[' ', `${k('from')} openai ${k('import')} OpenAI`], [' ', ''], [' ', 'client = OpenAI('], ['-', `    base_url=${s('"https://api.openai.com/v1"')},`], ['+', `    base_url=${s(`"${host}/v1"`)},`], [' ', `    api_key=os.environ[${s('"API_KEY"')}],`], [' ', ')']],
    'Node.js': [[' ', `${k('import')} OpenAI ${k('from')} ${s('"openai"')};`], [' ', ''], [' ', `${k('const')} client = ${k('new')} OpenAI({`], ['-', `  baseURL: ${s('"https://api.openai.com/v1"')},`], ['+', `  baseURL: ${s(`"${host}/v1"`)},`], [' ', '  apiKey: process.env.API_KEY,'], [' ', '});']],
    'curl': [['-', `curl ${s('https://api.openai.com/v1/chat/completions')} \\`], ['+', `curl ${s(`${host}/v1/chat/completions`)} \\`], [' ', `  -H ${s('"Authorization: Bearer $API_KEY"')} \\`], [' ', `  -H ${s('"Content-Type: application/json"')} \\`], [' ', `  -d ${s(`'{"model": "…", "messages": [...]}'`)}`]],
  };
  const plain = { 'Python': `from openai import OpenAI\n\nclient = OpenAI(\n    base_url="${host}/v1",\n    api_key=os.environ["API_KEY"],\n)`, 'Node.js': `import OpenAI from "openai";\n\nconst client = new OpenAI({\n  baseURL: "${host}/v1",\n  apiKey: process.env.API_KEY,\n});`, 'curl': `curl ${host}/v1/chat/completions \\\n  -H "Authorization: Bearer $API_KEY" \\\n  -H "Content-Type: application/json" \\\n  -d '{"model": "…", "messages": [...]}'` };
  LP.code = Object.fromEntries(Object.entries(tabs).map(([n, ls]) => [n, ls.map(([m, t], i) => `<div class="lp-ln ${m === '-' ? 'del' : m === '+' ? 'add' : ''}"><span class="lp-g">${i + 1}</span><span class="lp-m">${m === ' ' ? '' : m}</span><span class="lp-t">${t || ' '}</span></div>`).join('')]));
  LP.plain = plain;
  return `<div class="lp-code-h"><div class="lp-tabs" role="tablist">${Object.keys(tabs).map((n, i) => `<button role="tab" class="${i ? '' : 'on'}" data-tab="${n}">${n}</button>`).join('')}</div>${copyBtn(plain.Python, 'btn sm icon ghost lp-cp')}</div>
    <div class="lp-code-b" id="lpCodeB">${LP.code.Python}</div>`;
}
function lpTabs(box) {
  if (!box) return;
  const b = $('#lpCodeB'), cp = $('.lp-cp', box);
  $$('[data-tab]', box).forEach(btn => btn.onclick = () => {
    $$('[data-tab]', box).forEach(x => x.classList.toggle('on', x === btn));
    b.innerHTML = LP.code[btn.dataset.tab]; cp.dataset.copy = LP.plain[btn.dataset.tab]; });
}

// ---------- model status (compact table)
const lpStatusSkel = () => `<div class="tbl-wrap"><table><tbody>${'<tr><td colspan="4"><div class="skel" style="height:16px"></div></td></tr>'.repeat(4)}</tbody></table></div>`;
async function lpStatus() {
  const box = $('#lpSt'); if (!box) return;
  let d; try { d = await api('/api/public/status'); } catch { if (box.isConnected) { box.closest('[data-sec]').remove(); $('.lp-nav [data-go=status]')?.remove(); } return; }
  if (!box.isConnected) return;
  const k = ST[d.overall][1], ban = { ok: 'Все модели работают', degraded: 'Некоторые модели работают нестабильно', down: 'Часть моделей сейчас недоступна' }[d.overall];
  const hh = iso => new Date(iso).toLocaleTimeString(I18N.locale(), { hour: '2-digit', minute: '2-digit' });
  const ms = d.models, MAX = 8, pct = v => v == null ? '—' : String(v).replace('.', I18N.lang === 'ru' ? ',' : '.') + '%';
  box.innerHTML = `<div class="lp-st-sum"><span class="st-dot st-${k}"></span><b>${ban}</b><span class="dim small">${I18N.t('обновлено')} ${hh(d.updated_at)}</span></div>
    ${ms.length ? `<div class="tbl-wrap"><table class="lp-st"><thead><tr><th>Модель</th><th>Состояние</th><th class="r">Доступность</th><th class="r">Задержка</th><th class="lp-st-bh">24 часа</th></tr></thead><tbody>
      ${ms.slice(0, MAX).map(m => `<tr><td class="mono" data-noi18n>${esc(m.id)}</td><td><span class="st-t st-${ST[m.status][1]}">${ST[m.status][0]}</span></td><td class="r num">${pct(m.uptime)}</td><td class="r num">${lpLat(m.latency_ms)}</td>
        <td class="lp-st-bh"><div class="st-bars lp-bars">${m.hours.map(b => `<i class="st-${ST[b.level][1]}"></i>`).join('')}</div></td></tr>`).join('')}
    </tbody></table></div>${ms.length > MAX ? `<p class="mt"><a href="#/status" class="lp-more">Все модели на странице статуса</a> <span class="dim small">(${ms.length})</span></p>` : ''}` : '<div class="lp-empty">Моделей пока нет</div>'}`;
  if (!LP.stT) LP.stT = setInterval(() => { if (!$('#lpSt')) { clearInterval(LP.stT); LP.stT = 0; return; } lpStatus(); }, 60000);
}

const lpLat = v => v == null ? '—' : v < 1000 ? v + ' ' + I18N.t('мс') : String((v / 1000).toFixed(1)).replace('.', I18N.lang === 'ru' ? ',' : '.') + (I18N.lang === 'en' ? ' s' : ' с');

// ---------- helpers
function lpGo(id) {
  const t = id === 'top' ? 0 : ($(`[data-sec="${id}"]`)?.getBoundingClientRect().top ?? 0) + scrollY - 60;
  scrollTo({ top: Math.max(0, t), behavior: REDUCED() ? 'auto' : 'smooth' });
}
function lpLogin(q) {
  if ($('.ov .auth-m')) return;
  const o = S.cfg.oauth || {}, any = o.github || o.google;
  modal('Вход и регистрация', `<p class="muted" style="margin:-4px 0 20px">Аккаунт создаётся автоматически при первом входе</p>
    ${q.error ? `<div class="alert err small" style="margin-bottom:14px">${esc(q.error)}</div>` : ''}
    ${localStorage.getItem('ref') && S.cfg.referral?.enabled && S.cfg.referral.friend_bonus > 0 ? `<div class="alert info ico small" style="margin-bottom:14px">${ic('gift')}<span>Вас пригласил друг: после регистрации на баланс придёт <b>${money(S.cfg.referral.friend_bonus, 2)}</b> на использование API.</span></div>` : ''}
    ${any ? `<div class="col">${o.github ? `<a class="btn oauth" href="/api/auth/oauth/github/start">${GH_SVG}Продолжить с GitHub</a>` : ''}${o.google ? `<a class="btn oauth" href="/api/auth/oauth/google/start">${G_SVG}Продолжить с Google</a>` : ''}</div>`
      : `<div class="alert warn small">Вход ещё не настроен. Администратор: войдите по паролю и укажите ключи GitHub/Google в настройках.</div>`}
    <p class="small dim" style="margin:20px 0 0">Продолжая, вы принимаете условия использования сервиса.</p>`, { size: 'auth-m' });
  if (/^#\/(login|register)/.test(location.hash)) history.replaceState(null, '', location.pathname + '#/');
}
