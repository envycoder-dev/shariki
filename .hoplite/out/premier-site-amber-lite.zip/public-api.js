'use strict';
// OpenAI-compatible inference API. Never exposes provider keys or accepts provider URLs.
const crypto = require('node:crypto');
const { publicId, findModel } = require('./model-ids');
const { events, timeoutMs } = require('./chat-stream');
const fail = (res, status, message, code, param = null) => {
  const data = { error: { message, type: status === 401 ? 'authentication_error' : status >= 500 ? 'server_error' : 'invalid_request_error', param, code } };
  if (res.headersSent) { if (!res.destroyed) res.end('data: ' + JSON.stringify(data) + '\n\ndata: [DONE]\n\n'); }
  else { res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8' }); res.end(JSON.stringify(data)); }
};
const bad = (message, param) => { throw Object.assign(new Error(message), { status: 400, param }); };
const usageOf = u => ({ input_tokens: u?.prompt_tokens ?? 0, output_tokens: u?.completion_tokens ?? 0, total_tokens: u?.total_tokens ?? 0 });
function validate(b, model, cap) {
  if (!b || Array.isArray(b) || typeof b !== 'object') bad('Expected a JSON object.');
  const allowed = new Set(['model', 'messages', 'stream', 'stream_options', 'temperature', 'top_p', 'max_tokens', 'max_completion_tokens', 'stop', 'frequency_penalty', 'presence_penalty', 'seed', 'n', 'tools', 'tool_choice', 'parallel_tool_calls', 'response_format', 'user']);
  for (const k of Object.keys(b)) if (!allowed.has(k)) bad('Unsupported parameter: ' + k, k);
  if (!Array.isArray(b.messages) || !b.messages.length || b.messages.length > 500) bad('messages must contain 1–500 messages.', 'messages');
  const messages = b.messages.map((m) => {
    if (!m || !['system', 'developer', 'user', 'assistant', 'tool'].includes(m.role)) bad('Invalid message role.', 'messages');
    if (typeof m.content !== 'string' && !Array.isArray(m.content) && !(m.role === 'assistant' && m.content == null && Array.isArray(m.tool_calls) && m.tool_calls.length)) bad('Invalid message content.', 'messages');
    if (Array.isArray(m.content)) for (const part of m.content) {
      if (!part || !['text', 'image_url'].includes(part.type)) bad('Only text and image_url content parts are supported.', 'messages');
      if (part.type === 'text' && typeof part.text !== 'string') bad('Invalid text content.', 'messages');
      if (part.type === 'image_url' && (!model.vision || typeof part.image_url?.url !== 'string' || !/^(https?:\/\/|data:image\/)/.test(part.image_url.url))) bad('This model does not support this image input.', 'messages');
    }
    if (m.role === 'tool' && typeof m.tool_call_id !== 'string') bad('tool messages require tool_call_id.', 'messages');
    const x = { role: m.role, content: m.content ?? null };
    for (const k of ['name', 'tool_call_id', 'tool_calls']) if (m[k] !== undefined) x[k] = m[k];
    return x;
  });
  if (b.stream !== undefined && typeof b.stream !== 'boolean') bad('stream must be a boolean.', 'stream');
  if (b.n !== undefined && b.n !== 1) bad('Only n=1 is supported.', 'n');
  for (const [k, min, max] of [['temperature', 0, 2], ['top_p', 0, 1], ['frequency_penalty', -2, 2], ['presence_penalty', -2, 2]])
    if (b[k] !== undefined && (typeof b[k] !== 'number' || !Number.isFinite(b[k]) || b[k] < min || b[k] > max)) bad('Invalid ' + k + '.', k);
  if (b.max_tokens !== undefined && b.max_completion_tokens !== undefined) bad('Use only one token limit.');
  const tk = b.max_completion_tokens !== undefined ? 'max_completion_tokens' : 'max_tokens';
  if (b[tk] !== undefined && (!Number.isInteger(b[tk]) || b[tk] <= 0)) bad('Token limit must be a positive integer.', tk);
  if (b.stop !== undefined && !(typeof b.stop === 'string' || (Array.isArray(b.stop) && b.stop.length <= 4 && b.stop.every(s => typeof s === 'string')))) bad('Invalid stop.', 'stop');
  if (b.seed !== undefined && !Number.isSafeInteger(b.seed)) bad('seed must be an integer.', 'seed');
  if (b.tools !== undefined && (!Array.isArray(b.tools) || b.tools.length > 128 || b.tools.some(t => t?.type !== 'function' || typeof t.function?.name !== 'string'))) bad('Invalid tools.', 'tools');
  if (b.parallel_tool_calls !== undefined && typeof b.parallel_tool_calls !== 'boolean') bad('Invalid parallel_tool_calls.', 'parallel_tool_calls');
  if (b.response_format !== undefined && (!b.response_format || !['text', 'json_object', 'json_schema'].includes(b.response_format.type))) bad('Invalid response_format.', 'response_format');
  if (b.stream_options !== undefined && (!b.stream || !b.stream_options || typeof b.stream_options.include_usage !== 'boolean' || Object.keys(b.stream_options).some(k => k !== 'include_usage'))) bad('Only stream_options.include_usage is supported.', 'stream_options');
  const body = { model: model.modelId, messages, stream: b.stream === true };
  for (const k of allowed) if (!['model', 'messages', 'max_tokens', 'max_completion_tokens', 'n'].includes(k) && b[k] !== undefined) body[k] = b[k];
  const tokens = cap == null ? b[tk] : Math.min(b[tk] || cap, cap);
  if (tokens != null) body[tk] = tokens;
  // API has no site tools or memory. Apply only the admin's model-specific prompt.
  if (model.prompt?.trim()) body.messages.unshift({ role: 'system', content: model.prompt.trim() });
  return body;
}
// OpenAI Responses API (Codex CLI & co). Normalizes the richer input model to chat
// messages and answers with a `response` object or the Responses SSE event sequence.
// Unknown extra parameters (reasoning, store, metadata, text, include, …) are ignored.
function responsesToMessages(b, model) {
  const system = [], msgs = [];
  const addSystem = t => { if (typeof t === 'string' && t.trim()) system.push(t.trim()); };
  addSystem(b.instructions);
  if (Array.isArray(b.instructions)) for (const p of b.instructions) addSystem(typeof p === 'string' ? p : p?.text);
  if (typeof b.input === 'string') { if (b.input.trim()) msgs.push({ role: 'user', content: b.input }); }
  else if (Array.isArray(b.input)) {
    if (b.input.length > 500) bad('input must contain at most 500 items.', 'input');
    for (const it of b.input) {
      if (!it || typeof it !== 'object') continue;
      const type = it.type === undefined ? 'message' : it.type;
      if (type === 'function_call') {
        if (typeof it.call_id !== 'string' || !it.call_id || typeof it.name !== 'string' || !it.name) bad('Invalid function_call item.', 'input');
        msgs.push({ role: 'assistant', content: null, tool_calls: [{ id: it.call_id, type: 'function', function: { name: it.name, arguments: typeof it.arguments === 'string' ? it.arguments : JSON.stringify(it.arguments ?? {}) } }] });
      } else if (type === 'function_call_output') {
        if (typeof it.call_id !== 'string' || !it.call_id) bad('Invalid function_call_output item.', 'input');
        msgs.push({ role: 'tool', tool_call_id: it.call_id, content: typeof it.output === 'string' ? it.output : JSON.stringify(it.output ?? '') });
      } else if (type === 'message' || type === undefined) {
        const role = it.role === 'assistant' ? 'assistant' : it.role === 'system' || it.role === 'developer' ? 'system' : 'user';
        let content = '';
        if (typeof it.content === 'string') content = it.content;
        else if (Array.isArray(it.content)) {
          const parts = [];
          for (const p of it.content) {
            if (typeof p === 'string') { if (p) parts.push({ type: 'text', text: p }); continue; }
            if (!p || typeof p !== 'object') continue;
            if (p.type === 'input_text' || p.type === 'output_text' || p.type === 'text') { if (typeof p.text === 'string' && p.text) parts.push({ type: 'text', text: p.text }); }
            else if (p.type === 'input_image' && model.vision && typeof p.image_url?.url === 'string' && /^(https?:\/\/|data:image\/)/.test(p.image_url.url)) parts.push({ type: 'image_url', image_url: p.image_url });
          }
          content = parts.length ? parts : '';
        }
        if (role === 'system') { addSystem(Array.isArray(content) ? content.map(x => x.text).join('\n') : content); continue; }
        if (content === '' || (Array.isArray(content) && !content.length)) continue;
        msgs.push({ role, content });
      }
    }
  }
  if (system.length) msgs.unshift({ role: 'system', content: system.join('\n\n') });
  if (model.prompt?.trim()) msgs.unshift({ role: 'system', content: model.prompt.trim() });
  if (!msgs.length) bad('input must contain at least one message.', 'input');
  return msgs;
}
function validateResponses(b, model, cap) {
  if (b.previous_response_id !== undefined) bad('previous_response_id is not supported.', 'previous_response_id');
  if (b.stream !== undefined && typeof b.stream !== 'boolean') bad('stream must be a boolean.', 'stream');
  if (b.temperature !== undefined && (typeof b.temperature !== 'number' || !Number.isFinite(b.temperature) || b.temperature < 0 || b.temperature > 2)) bad('Invalid temperature.', 'temperature');
  if (b.top_p !== undefined && (typeof b.top_p !== 'number' || !Number.isFinite(b.top_p) || b.top_p < 0 || b.top_p > 1)) bad('Invalid top_p.', 'top_p');
  if (b.max_output_tokens !== undefined && (!Number.isInteger(b.max_output_tokens) || b.max_output_tokens <= 0)) bad('max_output_tokens must be a positive integer.', 'max_output_tokens');
  if (b.parallel_tool_calls !== undefined && typeof b.parallel_tool_calls !== 'boolean') bad('Invalid parallel_tool_calls.', 'parallel_tool_calls');
  const body = { model: model.modelId, messages: responsesToMessages(b, model), stream: b.stream === true };
  for (const k of ['temperature', 'top_p', 'parallel_tool_calls']) if (b[k] !== undefined) body[k] = b[k];
  if (b.max_output_tokens !== undefined) body.max_tokens = cap == null ? b.max_output_tokens : Math.min(b.max_output_tokens, cap);
  if (b.tools !== undefined) {
    if (!Array.isArray(b.tools) || b.tools.length > 128) bad('Invalid tools.', 'tools');
    const tools = b.tools.filter(t => t && t.type === 'function' && (typeof t.name === 'string' || typeof t.function?.name === 'string'))
      .map(t => ({ type: 'function', function: { name: t.name || t.function.name, ...(t.description !== undefined ? { description: t.description } : {}), parameters: t.parameters ?? t.function?.parameters ?? { type: 'object', properties: {} } } }));
    if (tools.length) body.tools = tools;
  }
  const tc = b.tool_choice;
  if (typeof tc === 'string' && ['auto', 'none', 'required'].includes(tc)) body.tool_choice = tc;
  else if (tc && tc.type === 'function' && typeof tc.name === 'string') body.tool_choice = { type: 'function', function: { name: tc.name } };
  return body;
}
function createPublicApi({ keys, bill, loadModels, readBody, endpoint, clientIp }) {
  const active = new Map(), failures = new Map();
  const cleanup = setInterval(() => { const now = Date.now(); for (const [ip, x] of failures) if (x.until <= now) failures.delete(ip); }, 60000); cleanup.unref();
  return async function handle(req, res, url) {
    res.setHeader('Cache-Control', 'no-store');
    const ip = clientIp(req), attempts = failures.get(ip);
    if (attempts?.until > Date.now() && attempts.n >= 30) { res.setHeader('Retry-After', '60'); return fail(res, 429, 'Too many authentication attempts.', 'rate_limit_exceeded'); }
    const auth = keys.authenticate(req.headers.authorization);
    if (!auth) {
      if (!attempts || attempts.until <= Date.now()) { if (failures.size >= 10000) failures.delete(failures.keys().next().value); failures.set(ip, { n: 1, until: Date.now() + 60000 }); } else attempts.n++;
      return fail(res, 401, 'Invalid, expired or revoked API key.', 'invalid_api_key');
    }
    const { user } = auth, p = url.pathname, km = auth.keyModels;
    const modelAllowed = m => !km || km.includes(m.id) || km.includes(publicId(m));
    const models = loadModels().filter(m => bill.modelPlans(m).includes(bill.planOf(user).id)).filter(modelAllowed);
    const object = m => ({ id: publicId(m), object: 'model', created: 0, owned_by: 'premier', name: m.name, vision: !!m.vision, weight: Math.max(1, Number(m.weight) || 1) });
    if (p === '/v1/models' && req.method === 'GET') { res.writeHead(200, { 'Content-Type': 'application/json' }); return res.end(JSON.stringify({ object: 'list', data: models.map(object) })); }
    if (p.startsWith('/v1/models/') && req.method === 'GET') {
      const m = findModel(models, p.slice(11));
      if (!m) return fail(res, 404, 'Model not found or not available on your plan.', 'model_not_found', 'model');
      res.writeHead(200, { 'Content-Type': 'application/json' }); return res.end(JSON.stringify(object(m)));
    }
    const isResp = p === '/v1/responses';
    if (!isResp && p !== '/v1/chat/completions') return fail(res, 404, 'Endpoint not found.', 'not_found');
    if (req.method !== 'POST') { res.setHeader('Allow', 'POST'); return fail(res, 405, 'Use POST.', 'method_not_allowed'); }
    let b, model, body;
    try {
      b = await readBody(req, 1e6);
      if (typeof b?.model !== 'string' || !b.model) bad('model is required.', 'model');
      model = findModel(loadModels(), b.model);
      if (!model) return fail(res, 404, 'Model not found.', 'model_not_found', 'model');
      if (km && !modelAllowed(model)) return fail(res, 403, 'Model not allowed for this API key.', 'model_not_allowed', 'model');
      body = isResp ? validateResponses(b, model, bill.maxTokens(user)) : validate(b, model, bill.maxTokens(user));
    } catch (e) { return fail(res, e.status || 400, e.message === 'bad json' ? 'Invalid JSON.' : e.message, 'invalid_request', e.param); }
    if ((active.get(user.id) || 0) >= 2) { res.setHeader('Retry-After', '5'); return fail(res, 429, 'Maximum 2 concurrent requests per account.', 'rate_limit_exceeded'); }
    const charge = bill.charge(user, model);
    if (charge.error) { if (charge.code !== 'model') res.setHeader('Retry-After', charge.code === 'burst' ? '300' : String(Math.ceil((Date.parse(bill.today() + 'T21:00:00Z') - Date.now()) / 1000))); return fail(res, charge.code === 'model' ? 403 : 429, charge.error, charge.code === 'model' ? 'model_not_allowed' : 'insufficient_quota'); }
    bill.flush(); // API reservations persist immediately, including concurrent callers.
    const chargedDay = bill.today();
    active.set(user.id, (active.get(user.id) || 0) + 1);
    const ac = new AbortController(), onClose = () => { if (!res.writableEnded) ac.abort(); };
    res.on('close', onClose);
    const signal = AbortSignal.any([ac.signal, AbortSignal.timeout(timeoutMs())]);
    const id = 'chatcmpl-' + crypto.randomBytes(16).toString('hex'), rid = 'resp_' + crypto.randomBytes(16).toString('hex'), created = Math.floor(Date.now() / 1000);
    let delivered = false;
    const output = j => ({ id, object: body.stream ? 'chat.completion.chunk' : 'chat.completion', created, model: publicId(model),
      choices: j.choices.map((c, i) => ({ index: c.index ?? i, [body.stream ? 'delta' : 'message']: c[body.stream ? 'delta' : 'message'] || {}, finish_reason: c.finish_reason ?? null, ...(c.logprobs ? { logprobs: c.logprobs } : {}) })), ...(j.usage ? { usage: j.usage } : {}) });
    const meaningful = c => !!(c?.content || c?.reasoning_content || c?.reasoning || c?.refusal || c?.tool_calls?.length);
    const write = async text => {
      if (res.destroyed) throw new Error('disconnected');
      if (!res.write(text)) await new Promise((resolve, reject) => {
        const done = () => { clean(); resolve(); }, close = () => { clean(); reject(new Error('disconnected')); }, clean = () => { res.off('drain', done); res.off('close', close); };
        res.once('drain', done); res.once('close', close);
      });
    };
    try {
      const r = await fetch(endpoint(model.baseUrl), { method: 'POST', signal, headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + model.apiKey }, body: JSON.stringify(body) });
      if (!r.ok) { if (r.body) await r.body.cancel(); throw new Error('upstream'); }
      if (!body.stream) {
        const j = await r.json();
        if (isResp) {
          if (j.error || !Array.isArray(j.choices) || !j.choices.length) throw new Error('upstream');
          const m = j.choices[0].message || {};
          const ro = [];
          if (typeof m.content === 'string' && m.content) ro.push({ type: 'message', id: 'msg_' + crypto.randomBytes(10).toString('hex'), status: 'completed', role: 'assistant', content: [{ type: 'output_text', text: m.content, annotations: [] }] });
          for (const t of m.tool_calls || []) {
            if (!t || t.type !== 'function' || !t.function?.name) continue;
            ro.push({ type: 'function_call', id: 'fc_' + crypto.randomBytes(10).toString('hex'), call_id: t.id || 'call_' + crypto.randomBytes(8).toString('hex'), name: t.function.name, arguments: typeof t.function.arguments === 'string' ? t.function.arguments : JSON.stringify(t.function.arguments ?? {}), status: 'completed' });
          }
          if (!ro.length) throw new Error('upstream');
          if (res.destroyed) throw new Error('disconnected');
          res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
          res.end(JSON.stringify({ id: rid, object: 'response', created_at: created, status: 'completed', model: publicId(model), instructions: b.instructions ?? null, output: ro, error: null, incomplete_details: null, usage: usageOf(j.usage) }));
          delivered = true;
        } else {
          if (j.error || !Array.isArray(j.choices) || !j.choices.length || !j.choices.some(c => meaningful(c.message))) throw new Error('upstream');
          if (res.destroyed) throw new Error('disconnected');
          res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' }); res.end(JSON.stringify(output(j))); delivered = true;
        }
      } else if (isResp) {
        // Responses SSE: created → in_progress → item/part/argument deltas → completed (no [DONE]).
        let started = false, finished = false, finishReason = null, lastUsage = null;
        const ro = [];
        let msgId = null, msgText = '', msgIdx = -1;
        const tcs = [];
        const ev = (name, data) => write('event: ' + name + '\ndata: ' + JSON.stringify(data) + '\n\n');
        const streamObj = status => ({ id: rid, object: 'response', created_at: created, status, model: publicId(model), instructions: b.instructions ?? null, output: [], error: null, incomplete_details: null });
        const finalize = async () => {
          if (msgIdx >= 0) {
            ro[msgIdx] = { type: 'message', id: msgId, status: 'completed', role: 'assistant', content: msgText ? [{ type: 'output_text', text: msgText, annotations: [] }] : [] };
            await ev('response.output_text.done', { type: 'response.output_text.done', item_id: msgId, output_index: msgIdx, content_index: 0, text: msgText });
            await ev('response.content_part.done', { type: 'response.content_part.done', item_id: msgId, output_index: msgIdx, content_index: 0, part: { type: 'output_text', text: msgText, annotations: [] } });
            await ev('response.output_item.done', { type: 'response.output_item.done', output_index: msgIdx, item: ro[msgIdx] });
          }
          for (const x of tcs) {
            if (x.idx < 0) continue;
            ro[x.idx] = { type: 'function_call', id: x.itemId, call_id: x.id || 'call_' + crypto.randomBytes(8).toString('hex'), name: x.name, arguments: x.args, status: 'completed' };
            await ev('response.output_item.done', { type: 'response.output_item.done', output_index: x.idx, item: ro[x.idx] });
          }
        };
        for await (const j of events(r)) {
          if (!Array.isArray(j.choices)) throw new Error('upstream');
          if (j.usage) lastUsage = j.usage;
          if (!res.headersSent) res.writeHead(200, { 'Content-Type': 'text/event-stream; charset=utf-8', 'X-Accel-Buffering': 'no', Connection: 'keep-alive' });
          if (!started) { started = true; await ev('response.created', { type: 'response.created', response: streamObj('in_progress') }); await ev('response.in_progress', { type: 'response.in_progress', response: streamObj('in_progress') }); }
          for (const c of j.choices) {
            const d = c.delta || {};
            const chunk = [d.content, d.refusal].filter(x => typeof x === 'string' && x).join('');
            if (chunk) {
              if (msgIdx < 0) {
                msgIdx = ro.length; msgId = 'msg_' + crypto.randomBytes(10).toString('hex'); ro.push(null);
                await ev('response.output_item.added', { type: 'response.output_item.added', output_index: msgIdx, item: { type: 'message', id: msgId, status: 'in_progress', role: 'assistant', content: [] } });
                await ev('response.content_part.added', { type: 'response.content_part.added', item_id: msgId, output_index: msgIdx, content_index: 0, part: { type: 'output_text', text: '', annotations: [] } });
              }
              msgText += chunk; delivered = true;
              await ev('response.output_text.delta', { type: 'response.output_text.delta', item_id: msgId, output_index: msgIdx, content_index: 0, delta: chunk });
            }
            for (const t of d.tool_calls || []) {
              if (!t) continue;
              let x = tcs.find(y => y.key === (t.index ?? 0));
              if (!x) { x = { key: t.index ?? 0, id: null, name: '', args: '', itemId: 'fc_' + crypto.randomBytes(10).toString('hex'), idx: -1 }; tcs.push(x); }
              if (t.id) x.id = t.id;
              if (typeof t.function?.name === 'string') x.name += t.function.name;
              const argChunk = typeof t.function?.arguments === 'string' ? t.function.arguments : '';
              if (x.idx < 0 && (x.name || x.id || argChunk)) {
                x.idx = ro.length; ro.push(null);
                await ev('response.output_item.added', { type: 'response.output_item.added', output_index: x.idx, item: { type: 'function_call', id: x.itemId, call_id: x.id || '', name: x.name, arguments: '', status: 'in_progress' } });
              }
              if (argChunk && x.idx >= 0) { x.args += argChunk; delivered = true; await ev('response.function_call_arguments.delta', { type: 'response.function_call_arguments.delta', item_id: x.itemId, output_index: x.idx, delta: argChunk }); }
            }
            if (c.finish_reason != null && finishReason == null) { finishReason = c.finish_reason; await finalize(); }
          }
          if (finishReason != null) finished = true;
        }
        if (!finished || !delivered) throw new Error('upstream');
        await ev('response.completed', { type: 'response.completed', response: { ...streamObj('completed'), output: ro, usage: usageOf(lastUsage) } });
        res.end();
      } else {
        let finished = false;
        for await (const j of events(r)) {
          if (!Array.isArray(j.choices)) throw new Error('upstream');
          if (!res.headersSent) res.writeHead(200, { 'Content-Type': 'text/event-stream; charset=utf-8', 'X-Accel-Buffering': 'no', Connection: 'keep-alive' });
          await write('data: ' + JSON.stringify(output(j)) + '\n\n');
          if (j.choices.some(c => meaningful(c.delta))) delivered = true;
          if (j.choices.some(c => c.finish_reason != null)) finished = true;
        }
        if (!finished || !delivered) throw new Error('upstream');
        res.end('data: [DONE]\n\n');
      }
    } catch (e) {
      if (!res.destroyed) fail(res, signal.aborted && !ac.signal.aborted ? 504 : 502, signal.aborted && !ac.signal.aborted ? 'Model request timed out.' : 'Model provider could not complete the request.', 'upstream_error');
    } finally {
      ac.abort(); res.off('close', onClose);
      const count = (active.get(user.id) || 1) - 1; if (count) active.set(user.id, count); else active.delete(user.id);
      if (!delivered && chargedDay === bill.today()) { bill.add(user.id, 'm', -charge.weight); bill.flush(); }
    }
  };
}
module.exports = { createPublicApi, validate };
